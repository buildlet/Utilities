BUILDLet PowerShell PackageMaker Toolkit Readme サンプル
Copyright (C) __DATE__ BUILDLet

Dummy Package __VERSION__

これは Readme のダミーファイルです。
