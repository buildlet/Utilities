BUILDLet PowerShell PackageMaker Toolkit Readme Sample
Copyright (C) __DATE__ BUILDLet

Dummy Package __VERSION__

This is only a dummy file of Readme.
